import { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

declare global {
  interface Window {
    google: any;
    initMap: () => void;
  }
}

const LOGISTICS_HUBS = [
  { 
    name: 'بەندەری ئوم قەسر', 
    lat: 30.0381, 
    lng: 47.9261, 
    description: 'Umm Qasr Port',
    type: 'port'
  },
  { 
    name: 'دەروازەی ئیبراهیم خەلیل', 
    lat: 37.1594, 
    lng: 42.5639, 
    description: 'Ibrahim Khalil Border',
    type: 'border'
  },
  { 
    name: 'فڕۆکەخانەی هەولێر', 
    lat: 36.2369, 
    lng: 43.9592, 
    description: 'Erbil Airport',
    type: 'airport'
  },
];

const ICONS: Record<string, string> = {
  port: 'https://cdn-icons-png.flaticon.com/512/2892/2892695.png', // Ship
  border: 'https://cdn-icons-png.flaticon.com/512/2554/2554904.png', // Truck
  airport: 'https://cdn-icons-png.flaticon.com/512/2311/2311894.png', // Plane
};

export function LogisticsMap() {
  const mapRef = useRef<HTMLDivElement>(null);
  const isApiLoaded = !!(window.google && window.google.maps);

  useEffect(() => {
    if (!mapRef.current) return;

    const initMap = () => {
      if (!window.google || !window.google.maps) return;

      const map = new window.google.maps.Map(mapRef.current, {
        center: { lat: 33.3152, lng: 44.3661 }, // Baghdadish center
        zoom: 5,
        styles: [
          {
            featureType: 'all',
            elementType: 'labels.text.fill',
            style: { color: '#ffffff' }
          },
          {
            featureType: 'water',
            elementType: 'geometry',
            stylers: [{ color: '#0e1726' }]
          },
          {
            featureType: 'landscape',
            elementType: 'geometry',
            stylers: [{ color: '#1b2e4b' }]
          }
        ]
      });

      LOGISTICS_HUBS.forEach((hub) => {
        const marker = new window.google.maps.Marker({
          position: { lat: hub.lat, lng: hub.lng },
          map,
          title: hub.name,
          icon: {
            url: ICONS[hub.type],
            scaledSize: new window.google.maps.Size(32, 32),
            origin: new window.google.maps.Point(0, 0),
            anchor: new window.google.maps.Point(16, 32),
          },
          animation: window.google.maps.Animation.DROP
        });

        const infoWindow = new window.google.maps.InfoWindow({
          content: `
            <div style="color: #1e293b; padding: 8px; font-family: sans-serif;">
              <h3 style="margin: 0; font-size: 14px; font-weight: bold;">${hub.name}</h3>
              <p style="margin: 4px 0 0; font-size: 11px; color: #64748b;">${hub.description}</p>
            </div>
          `
        });

        marker.addListener('click', () => {
          infoWindow.open(map, marker);
        });
      });
    };

    if (isApiLoaded) {
      initMap();
    } else {
      window.initMap = initMap;
    }
  }, [isApiLoaded]);

  return (
    <Card className="border-none shadow-md bg-white dark:bg-slate-800 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/5">
      <CardHeader className="pb-3 border-b border-slate-100 dark:border-slate-700">
        <CardTitle className="text-lg flex items-center gap-2 text-primary">
          <MapPin className="w-5 h-5" />
          نەخشەی دەروازەکان
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-4 p-0 overflow-hidden relative">
        <div ref={mapRef} className="w-full h-48 md:h-64 rounded-b-xl" />
        {!isApiLoaded && (
          <div className="absolute inset-0 bg-slate-100 dark:bg-slate-900 flex flex-col items-center justify-center p-6 text-center rounded-b-xl">
            <div className="w-12 h-12 bg-slate-200 dark:bg-slate-800 rounded-full flex items-center justify-center mb-3">
              <MapPin className="w-6 h-6 text-slate-400" />
            </div>
            <p className="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">نەخشە کارا نەکراوە</p>
            <p className="text-xs text-slate-400">تکایە کلیلی Google Maps لە ڕێکخستنەکان دابنێ</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
